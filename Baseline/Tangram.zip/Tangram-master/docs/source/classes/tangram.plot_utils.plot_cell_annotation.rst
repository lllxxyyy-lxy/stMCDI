tangram.plot\_utils.plot\_cell\_annotation
==========================================

.. currentmodule:: tangram.plot_utils

.. autofunction:: plot_cell_annotation
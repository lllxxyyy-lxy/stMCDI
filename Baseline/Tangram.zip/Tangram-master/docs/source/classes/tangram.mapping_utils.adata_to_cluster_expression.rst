tangram.mapping\_utils.adata\_to\_cluster\_expression
=====================================================

.. currentmodule:: tangram.mapping_utils

.. autofunction:: adata_to_cluster_expression
tangram.utils.project\_genes
============================

.. currentmodule:: tangram.utils

.. autofunction:: project_genes
tangram.utils.cross\_val
========================

.. currentmodule:: tangram.utils

.. autofunction:: cross_val
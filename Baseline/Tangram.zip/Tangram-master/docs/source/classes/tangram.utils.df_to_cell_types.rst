tangram.utils.df\_to\_cell\_types
=================================

.. currentmodule:: tangram.utils

.. autofunction:: df_to_cell_types
tangram.utils.eval\_metric
==========================

.. currentmodule:: tangram.utils

.. autofunction:: eval_metric
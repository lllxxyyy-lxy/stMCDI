tangram.mapping\_optimizer.Mapper.train
=======================================

.. currentmodule:: tangram.mapping_optimizer

.. automethod:: Mapper.train
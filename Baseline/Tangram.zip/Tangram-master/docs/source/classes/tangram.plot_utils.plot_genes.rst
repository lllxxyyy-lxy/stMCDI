tangram.plot\_utils.plot\_genes
===============================

.. currentmodule:: tangram.plot_utils

.. autofunction:: plot_genes
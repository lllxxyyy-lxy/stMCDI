tangram.mapping\_utils.pp\_adatas
=================================

.. currentmodule:: tangram.mapping_utils

.. autofunction:: pp_adatas
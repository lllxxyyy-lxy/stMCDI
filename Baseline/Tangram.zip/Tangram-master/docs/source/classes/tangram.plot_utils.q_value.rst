tangram.plot\_utils.q\_value
============================

.. currentmodule:: tangram.plot_utils

.. autofunction:: q_value
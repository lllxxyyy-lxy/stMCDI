tangram.utils.deconvolve\_cell\_annotations
===========================================

.. currentmodule:: tangram.utils

.. autofunction:: deconvolve_cell_annotations
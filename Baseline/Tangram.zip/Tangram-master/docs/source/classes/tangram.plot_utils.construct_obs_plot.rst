tangram.plot\_utils.construct\_obs\_plot
========================================

.. currentmodule:: tangram.plot_utils

.. autofunction:: construct_obs_plot
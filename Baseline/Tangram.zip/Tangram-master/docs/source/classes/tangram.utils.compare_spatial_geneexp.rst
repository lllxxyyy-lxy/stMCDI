tangram.utils.compare\_spatial\_geneexp
=======================================

.. currentmodule:: tangram.utils

.. autofunction:: compare_spatial_geneexp
tangram.utils.cv\_data\_gen
===========================

.. currentmodule:: tangram.utils

.. autofunction:: cv_data_gen
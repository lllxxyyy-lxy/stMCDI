tangram.plot\_utils.plot\_auc
=============================

.. currentmodule:: tangram.plot_utils

.. autofunction:: plot_auc
﻿tangram.mapping\_optimizer
==========================

.. rubric:: Description

.. automodule:: tangram.mapping_optimizer

.. currentmodule:: tangram.mapping_optimizer


.. rubric:: Classes

.. autosummary::
    :toctree: .
    
    Mapper
    
    MapperConstrained
    




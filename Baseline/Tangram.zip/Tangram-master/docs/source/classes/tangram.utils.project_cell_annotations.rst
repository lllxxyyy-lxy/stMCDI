tangram.utils.project\_cell\_annotations
========================================

.. currentmodule:: tangram.utils

.. autofunction:: project_cell_annotations
tangram.plot\_utils.plot\_cell\_annotation\_sc
==============================================

.. currentmodule:: tangram.plot_utils

.. autofunction:: plot_cell_annotation_sc
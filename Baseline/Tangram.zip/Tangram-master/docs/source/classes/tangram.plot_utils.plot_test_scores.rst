tangram.plot\_utils.plot\_test\_scores
======================================

.. currentmodule:: tangram.plot_utils

.. autofunction:: plot_test_scores
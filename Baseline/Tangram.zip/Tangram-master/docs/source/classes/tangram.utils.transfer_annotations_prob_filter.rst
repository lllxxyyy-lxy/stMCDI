tangram.utils.transfer\_annotations\_prob\_filter
=================================================

.. currentmodule:: tangram.utils

.. autofunction:: transfer_annotations_prob_filter
tangram.utils.annotate\_gene\_sparsity
======================================

.. currentmodule:: tangram.utils

.. autofunction:: annotate_gene_sparsity
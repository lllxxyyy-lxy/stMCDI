tangram.mapping\_optimizer.MapperConstrained.train
==================================================

.. currentmodule:: tangram.mapping_optimizer

.. automethod:: MapperConstrained.train
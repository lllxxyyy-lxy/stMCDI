tangram.utils.transfer\_annotations\_prob
=========================================

.. currentmodule:: tangram.utils

.. autofunction:: transfer_annotations_prob
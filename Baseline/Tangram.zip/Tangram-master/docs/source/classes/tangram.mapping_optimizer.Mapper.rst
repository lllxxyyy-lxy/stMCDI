﻿tangram.mapping\_optimizer.Mapper
=================================

.. currentmodule:: tangram.mapping_optimizer

.. autoclass:: Mapper

   
   
   
   

   
      .. autosummary::
         :toctree:
      
         Mapper.train
   
   
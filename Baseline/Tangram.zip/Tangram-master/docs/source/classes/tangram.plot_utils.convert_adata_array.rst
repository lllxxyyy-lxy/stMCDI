tangram.plot\_utils.convert\_adata\_array
=========================================

.. currentmodule:: tangram.plot_utils

.. autofunction:: convert_adata_array
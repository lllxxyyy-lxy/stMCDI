﻿tangram.mapping\_optimizer.MapperConstrained
============================================

.. currentmodule:: tangram.mapping_optimizer

.. autoclass:: MapperConstrained

   
   
   
   

   
      .. autosummary::
         :toctree:
      
         MapperConstrained.train
   
   
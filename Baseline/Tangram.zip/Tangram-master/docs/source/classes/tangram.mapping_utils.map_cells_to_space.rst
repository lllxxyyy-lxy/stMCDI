tangram.mapping\_utils.map\_cells\_to\_space
============================================

.. currentmodule:: tangram.mapping_utils

.. autofunction:: map_cells_to_space
tangram.plot\_utils.quick\_plot\_gene
=====================================

.. currentmodule:: tangram.plot_utils

.. autofunction:: quick_plot_gene
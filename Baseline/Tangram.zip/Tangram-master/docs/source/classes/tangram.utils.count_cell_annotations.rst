tangram.utils.count\_cell\_annotations
======================================

.. currentmodule:: tangram.utils

.. autofunction:: count_cell_annotations
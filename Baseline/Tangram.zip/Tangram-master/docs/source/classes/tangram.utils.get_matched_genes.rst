tangram.utils.get\_matched\_genes
=================================

.. currentmodule:: tangram.utils

.. autofunction:: get_matched_genes
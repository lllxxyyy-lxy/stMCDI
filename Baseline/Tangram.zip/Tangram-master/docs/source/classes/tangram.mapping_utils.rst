﻿tangram.mapping\_utils
======================

.. rubric:: Description

.. automodule:: tangram.mapping_utils

.. currentmodule:: tangram.mapping_utils




.. rubric:: Functions

.. autosummary::
    :toctree: .
    
    adata_to_cluster_expression
    
    map_cells_to_space
    
    pp_adatas
    


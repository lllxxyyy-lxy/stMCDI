tangram.plot\_utils.plot\_gene\_sparsity
========================================

.. currentmodule:: tangram.plot_utils

.. autofunction:: plot_gene_sparsity
tangram.plot\_utils.plot\_annotation\_entropy
=============================================

.. currentmodule:: tangram.plot_utils

.. autofunction:: plot_annotation_entropy
tangram.utils.create\_segment\_cell\_df
=======================================

.. currentmodule:: tangram.utils

.. autofunction:: create_segment_cell_df
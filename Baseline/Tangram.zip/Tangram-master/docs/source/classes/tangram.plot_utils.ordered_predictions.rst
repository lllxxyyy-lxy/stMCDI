tangram.plot\_utils.ordered\_predictions
========================================

.. currentmodule:: tangram.plot_utils

.. autofunction:: ordered_predictions
Citing Tangram
===========================

Tangram has been released in the following publication

Biancalani* T., Scalia* G. et al. - _Deep learning and alignment of spatially-resolved whole transcriptomes of single cells in the mouse brain with *Tangram* `biorXiv 10.1101/2020.08.29.272831 <https://www.biorxiv.org/content/10.1101/2020.08.29.272831v3>`_ (2020)

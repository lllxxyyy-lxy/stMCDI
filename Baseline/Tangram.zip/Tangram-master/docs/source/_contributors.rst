.. sidebar:: Contributors 

   * `Tommaso Biancalani`_: author of method, PyPI maintainer :mod:`Contact: biancalt@gene.com`
   * Gabriele Scalia: author of method :mod:`Contact: gabriele.scalia@roche.com`
   * Ziqing Lu: PyPI maintainer :mod:`Contact: luz21@gene.com`
   * Shreya Gaddam: PyPI maintainer :mod:`Contact: gaddams@gene.com`
   * Anna Hupalowska: Artwork :mod:`Contact: ahupalow@broadinstitute.org`

.. _Tommaso Biancalani: https://twitter.com/tbyanc?lang=en
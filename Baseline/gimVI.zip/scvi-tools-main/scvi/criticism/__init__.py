from ._ppc import PosteriorPredictiveCheck

__all__ = ["PosteriorPredictiveCheck"]

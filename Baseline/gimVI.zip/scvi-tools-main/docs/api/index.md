# API

Import scvi-tools as:

```
import scvi
```

```{toctree}
:maxdepth: 2

user
developer
datasets
```

# training model
* python train_graph_cpg.py
# imputation code
* python imputation.py
# visualization code
* interpretation.ipynb
# [example datasets (google drive)](https://drive.google.com/drive/folders/1p2k_DMOfId1xqlvIv-B7D4rXtzpFlB-3?usp=sharing)
* HCC
* MBL
* Hemato



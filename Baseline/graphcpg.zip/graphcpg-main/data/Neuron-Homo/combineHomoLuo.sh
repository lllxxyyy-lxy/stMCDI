python ../CombineEncodedLabels.py --y_files y_* --pos_files pos_* --y_outFile y_Luo_Homo.npz --pos_outFile pos_Luo_Homo.npz
